#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import csv
import os
import re
import subprocess
from concurrent.futures import ThreadPoolExecutor, as_completed
from threading import Lock

CSV_FILE = "npm_github_mapping.csv"

REPO_DIR = "repos"

SUCCESS_FILE = "cloned_success.txt"
FAILED_FILE = "cloned_failed.txt"

MAX_WORKERS = 16

os.makedirs(REPO_DIR, exist_ok=True)

write_lock = Lock()


def parse_owner_repo(url):
    """
    https://github.com/user/repo
    -> (user, repo)
    """

    m = re.match(
        r"https?://github\.com/([^/]+)/([^/]+)",
        url.strip()
    )

    if not m:
        return None

    owner = m.group(1)

    repo = m.group(2)

    if repo.endswith(".git"):
        repo = repo[:-4]

    return owner, repo


def load_finished():
    finished = set()

    for path in [SUCCESS_FILE]:
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                for line in f:
                    finished.add(line.strip())

    return finished


def append_line(path, text):
    with write_lock:
        with open(path, "a", encoding="utf-8") as f:
            f.write(text + "\n")


def clone_repo(url):

    parsed = parse_owner_repo(url)

    if parsed is None:
        return False, url, "invalid url"

    owner, repo = parsed

    ssh_url = f"git@github.com:{owner}/{repo}.git"

    repo_dir = os.path.join(
        REPO_DIR,
        f"{owner}_{repo}.git"
    )

    if os.path.exists(repo_dir):
        return True, url, "already exists"

    cmd = [
        "git",
        "clone",
        "--mirror",
        ssh_url,
        repo_dir
    ]

    try:

        result = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=7200
        )

        if result.returncode == 0:
            append_line(SUCCESS_FILE, url)
            return True, url, "success"

        append_line(
            FAILED_FILE,
            f"{url}\t{result.stderr.strip()}"
        )

        return False, url, result.stderr.strip()

    except Exception as e:

        append_line(
            FAILED_FILE,
            f"{url}\t{str(e)}"
        )

        return False, url, str(e)


def main():

    urls = set()

    with open(CSV_FILE, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)

        for row in reader:
            url = row["github_url"].strip()

            if url:
                urls.add(url)

    print("Total unique repos:", len(urls))

    finished = load_finished()

    urls = [
        url
        for url in urls
        if url not in finished
    ]

    print("Already finished:", len(finished))
    print("Remaining:", len(urls))

    success = 0
    failed = 0

    try:

        with ThreadPoolExecutor(
            max_workers=MAX_WORKERS
        ) as executor:

            futures = {
                executor.submit(clone_repo, url): url
                for url in urls
            }

            total = len(futures)

            for idx, future in enumerate(
                as_completed(futures),
                start=1
            ):

                ok, url, msg = future.result()

                if ok:
                    success += 1
                else:
                    failed += 1

                print(
                    f"[{idx}/{total}] "
                    f"{'OK' if ok else 'FAIL'} "
                    f"{url}"
                )

    except KeyboardInterrupt:
        print("\nInterrupted.")
        print("Run again to resume.")

    print()
    print("=================================")
    print("Success:", success)
    print("Failed :", failed)


if __name__ == "__main__":
    main()