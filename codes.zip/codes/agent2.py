#!/usr/bin/env python3
# -*- coding:utf-8 -*-

import os
import json

###########################################################
# CONFIG
###########################################################

INPUT_DIR = "jsonl31"

OUTPUT_DIR = "jsonl32"

os.makedirs(
    OUTPUT_DIR,
    exist_ok=True
)

###########################################################
# Union Find
###########################################################

class UnionFind:

    def __init__(self):

        self.parent = {}

    def find(self, x):

        if x not in self.parent:

            self.parent[x] = x

        if self.parent[x] != x:

            self.parent[x] = self.find(
                self.parent[x]
            )

        return self.parent[x]

    def union(self, a, b):

        pa = self.find(a)
        pb = self.find(b)

        if pa != pb:

            self.parent[pb] = pa


###########################################################
# 单文件处理
###########################################################

def process_file(
    input_file,
    output_file
):

    print()
    print("=" * 80)
    print("Processing:", input_file)

    #######################################################
    # load
    #######################################################

    records = []

    with open(
        input_file,
        "r",
        encoding="utf-8"
    ) as f:

        for line in f:

            line = line.strip()

            if not line:
                continue

            try:

                obj = json.loads(
                    line
                )

                records.append(
                    obj
                )

            except:
                pass

    print(
        "records:",
        len(records)
    )

    #######################################################
    # build graph
    #######################################################

    uf = UnionFind()

    for obj in records:

        name = str(
            obj.get(
                "author_name",
                ""
            )
        ).strip()

        email = str(
            obj.get(
                "author_email",
                ""
            )
        ).strip()

        if not name or not email:
            continue

        uf.union(
            "N:" + name,
            "E:" + email
        )

    #######################################################
    # group id
    #######################################################

    group_map = {}

    next_group = 1

    for obj in records:

        name = str(
            obj.get(
                "author_name",
                ""
            )
        ).strip()

        email = str(
            obj.get(
                "author_email",
                ""
            )
        ).strip()

        if not name or not email:
            continue

        root = uf.find(
            "N:" + name
        )

        if root not in group_map:

            group_map[root] = (
                next_group
            )

            next_group += 1

    print(
        "groups:",
        len(group_map)
    )

    #######################################################
    # write
    #######################################################

    with open(
        output_file,
        "w",
        encoding="utf-8"
    ) as out:

        for obj in records:

            name = str(
                obj.get(
                    "author_name",
                    ""
                )
            ).strip()

            email = str(
                obj.get(
                    "author_email",
                    ""
                )
            ).strip()

            if name and email:

                root = uf.find(
                    "N:" + name
                )

                obj["group"] = (
                    group_map[root]
                )

            else:

                obj["group"] = -1

            out.write(
                json.dumps(
                    obj,
                    ensure_ascii=False
                )
                + "\n"
            )

    print(
        "saved:",
        output_file
    )


###########################################################
# main
###########################################################

def main():

    files = sorted(

        f

        for f in os.listdir(
            INPUT_DIR
        )

        if f.endswith(
            ".jsonl"
        )
    )

    print(
        "jsonl files:",
        len(files)
    )

    for file_name in files:

        input_file = os.path.join(
            INPUT_DIR,
            file_name
        )

        output_file = os.path.join(
            OUTPUT_DIR,
            file_name
        )

        try:

            process_file(
                input_file,
                output_file
            )

        except Exception as e:

            print(
                "FAILED:",
                file_name,
                e
            )

    print()
    print(
        "ALL DONE"
    )


if __name__ == "__main__":

    main()