#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import json
from collections import defaultdict

###########################################################
# CONFIG
###########################################################

INPUT_DIR = "jsonl32"

OUTPUT_DIR = "jsonl33"

os.makedirs(
    OUTPUT_DIR,
    exist_ok=True
)

###########################################################
# 单文件处理
###########################################################

def process_file(
    input_file,
    output_file
):

    print()
    print("=" * 80)
    print("Processing:", input_file)

    #######################################################
    # 读取全部记录
    #######################################################

    records = []

    with open(
        input_file,
        "r",
        encoding="utf-8"
    ) as f:

        for line in f:

            line = line.strip()

            if not line:
                continue

            try:

                obj = json.loads(line)

                records.append(obj)

            except Exception:
                pass

    print(
        "records:",
        len(records)
    )

    #######################################################
    # group -> unique(name,email)
    #######################################################

    group_pairs = defaultdict(set)

    for obj in records:

        group = obj.get(
            "group",
            -1
        )

        if group == -1:
            continue

        name = str(
            obj.get(
                "author_name",
                ""
            )
        ).strip()

        email = str(
            obj.get(
                "author_email",
                ""
            )
        ).strip()

        group_pairs[group].add(
            (
                name,
                email
            )
        )

    #######################################################
    # group -> multi_accounts
    #######################################################

    group_multi = {}

    multi_account_groups = 0

    for (
        group,
        pairs
    ) in group_pairs.items():

        unique_count = len(
            pairs
        )

        group_multi[group] = (
            unique_count
        )

        if unique_count > 1:

            multi_account_groups += 1

    print(
        "groups:",
        len(group_multi)
    )

    print(
        "multi-account groups:",
        multi_account_groups
    )

    #######################################################
    # 更新 multi_accounts
    #######################################################

    updated_records = 0

    for obj in records:

        group = obj.get(
            "group",
            -1
        )

        if group == -1:
            continue

        multi_accounts = (
            group_multi.get(
                group,
                1
            )
        )

        try:

            obj["user"][
                "identity"
            ][
                "multi_accounts"
            ] = multi_accounts

            updated_records += 1

        except Exception:

            pass

    print(
        "updated records:",
        updated_records
    )

    #######################################################
    # 输出
    #######################################################

    with open(
        output_file,
        "w",
        encoding="utf-8"
    ) as out:

        for obj in records:

            out.write(
                json.dumps(
                    obj,
                    ensure_ascii=False
                )
                + "\n"
            )

    print(
        "saved:",
        output_file
    )


###########################################################
# main
###########################################################

def main():

    files = sorted(

        f

        for f in os.listdir(
            INPUT_DIR
        )

        if f.endswith(
            ".jsonl"
        )
    )

    print(
        "jsonl files:",
        len(files)
    )

    total_groups = 0

    total_files = 0

    for file_name in files:

        input_file = os.path.join(
            INPUT_DIR,
            file_name
        )

        output_file = os.path.join(
            OUTPUT_DIR,
            file_name
        )

        try:

            process_file(
                input_file,
                output_file
            )

            total_files += 1

        except Exception as e:

            print(
                "FAILED:",
                file_name,
                e
            )

    print()
    print("=" * 80)
    print("ALL DONE")
    print(
        "processed files:",
        total_files
    )
    print("=" * 80)


###########################################################
# entry
###########################################################

if __name__ == "__main__":

    main()