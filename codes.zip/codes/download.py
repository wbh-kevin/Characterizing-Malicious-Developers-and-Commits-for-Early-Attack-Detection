#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import re
import csv
import json
import tarfile

INPUT_DIR = "tgz"
OUTPUT_CSV = "npm_github_mapping.csv"


def normalize_github_url(url):
    """
    将各种 github 表达形式统一成:
    https://github.com/user/repo
    """

    if not url:
        return None

    url = str(url).strip()

    # github:user/repo
    m = re.match(r"^github:([^/]+)/([^/]+)$", url)
    if m:
        return f"https://github.com/{m.group(1)}/{m.group(2)}"

    url = url.replace("git+", "")
    url = url.replace("git://", "https://")

    # git@github.com:user/repo.git
    m = re.match(
        r"git@github\.com:([^/]+)/([^/]+?)(?:\.git)?$",
        url
    )
    if m:
        return f"https://github.com/{m.group(1)}/{m.group(2)}"

    # https://github.com/user/repo(.git)
    m = re.search(
        r"github\.com[:/]+([^/]+)/([^/#?]+)",
        url
    )
    if m:
        repo = m.group(2)
        if repo.endswith(".git"):
            repo = repo[:-4]
        return f"https://github.com/{m.group(1)}/{repo}"

    return None


def find_github_in_json(obj):
    """
    深度搜索整个 package.json，
    找到第一个 github 地址
    """
    if isinstance(obj, dict):
        for v in obj.values():
            result = find_github_in_json(v)
            if result:
                return result

    elif isinstance(obj, list):
        for item in obj:
            result = find_github_in_json(item)
            if result:
                return result

    elif isinstance(obj, str):
        result = normalize_github_url(obj)
        if result:
            return result

    return None


def extract_package_json_from_tgz(tgz_path):
    """
    npm tgz通常为:
    package/package.json
    """
    try:
        with tarfile.open(tgz_path, "r:gz") as tar:

            package_json_member = None

            for member in tar.getmembers():
                name = member.name.lower()

                if name.endswith("/package.json"):
                    package_json_member = member
                    break

                if name == "package.json":
                    package_json_member = member
                    break

            if package_json_member is None:
                return None

            f = tar.extractfile(package_json_member)
            if f is None:
                return None

            return json.load(f)

    except Exception:
        return None


def main():
    rows = []

    total_tgz = 0
    found_github = 0

    for root, _, files in os.walk(INPUT_DIR):
        for filename in files:

            if not filename.endswith(".tgz"):
                continue

            total_tgz += 1

            tgz_path = os.path.join(root, filename)

            if total_tgz % 1000 == 0:
                print(
                    f"Processed {total_tgz} packages, "
                    f"found {found_github} github repos..."
                )

            package_json = extract_package_json_from_tgz(tgz_path)

            if not package_json:
                continue

            package_name = package_json.get("name", "")

            github_url = None

            # 优先 repository
            repository = package_json.get("repository")

            if isinstance(repository, str):
                github_url = normalize_github_url(repository)

            elif isinstance(repository, dict):
                github_url = normalize_github_url(
                    repository.get("url")
                )

            # homepage
            if not github_url:
                github_url = normalize_github_url(
                    package_json.get("homepage")
                )

            # bugs.url
            if not github_url:
                bugs = package_json.get("bugs")
                if isinstance(bugs, dict):
                    github_url = normalize_github_url(
                        bugs.get("url")
                    )

            # 整个 json 深度搜索
            if not github_url:
                github_url = find_github_in_json(package_json)

            if github_url:
                found_github += 1

                rows.append([
                    package_name,
                    github_url,
                    filename
                ])

    with open(
        OUTPUT_CSV,
        "w",
        newline="",
        encoding="utf-8"
    ) as f:
        writer = csv.writer(f)

        writer.writerow([
            "package_name",
            "github_url",
            "tgz_file"
        ])

        writer.writerows(rows)

    print()
    print("Done")
    print("Total tgz files :", total_tgz)
    print("GitHub found    :", found_github)
    print("Output          :", OUTPUT_CSV)


if __name__ == "__main__":
    main()