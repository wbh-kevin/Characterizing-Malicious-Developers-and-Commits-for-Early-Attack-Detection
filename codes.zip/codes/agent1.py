#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import json
import time
import requests
import subprocess

from tqdm import tqdm

from pathlib import Path
from statistics import median
from collections import defaultdict
from datetime import datetime, timezone


############################################################
# CONFIG
############################################################

REPOS_ROOT = "repos"

OUTPUT_DIR = "jsonl31"

CACHE_FILE = "github_cache.json"

GITHUB_TOKEN = ""

HEADERS = {
    "Authorization": f"Bearer {GITHUB_TOKEN}",
    "Accept": "application/vnd.github+json"
}

PUBLIC_EMAIL_DOMAINS = {

    "gmail.com",
    "qq.com",
    "163.com",
    "126.com",

    "hotmail.com",
    "outlook.com",
    "foxmail.com",

    "yahoo.com",

    "proton.me",
    "protonmail.com"
}

############################################################
# cache
############################################################

search_cache = {}

profile_cache = {}

github_cache = {}

############################################################
# github helper
############################################################

def github_get(
    url,
    params=None,
    retry=5
):

    for _ in range(retry):

        try:

            r = requests.get(
                url,
                headers=HEADERS,
                params=params,
                timeout=30
            )

            if r.status_code == 200:

                return r.json()

            elif r.status_code == 403:

                reset = r.headers.get(
                    "X-RateLimit-Reset"
                )

                if reset:

                    wait = (
                        int(reset)
                        - int(time.time())
                        + 5
                    )

                    if wait > 0:

                        print(
                            f"\nRateLimit sleep {wait}s"
                        )

                        time.sleep(wait)

                        continue

                time.sleep(60)

            elif r.status_code in [
                404,
                422
            ]:

                return None

            else:

                print(
                    "status:",
                    r.status_code
                )

                time.sleep(5)

        except Exception as e:

            print(
                "github_get:",
                e
            )

            time.sleep(5)

    return None


############################################################
# search github user
############################################################

def search_user_by_email(
    email
):

    if not email:

        return None

    if email in search_cache:

        return search_cache[email]

    data = github_get(
        "https://api.github.com/search/users",
        {
            "q": email
        }
    )

    login = None

    if data:

        items = data.get(
            "items",
            []
        )

        if len(items):

            login = items[0][
                "login"
            ]

    search_cache[email] = login

    return login


def search_user_by_name(
    name
):

    if not name:

        return None

    key = f"name::{name}"

    if key in search_cache:

        return search_cache[key]

    data = github_get(
        "https://api.github.com/search/users",
        {
            "q":
            f"{name} in:fullname"
        }
    )

    login = None

    if data:

        items = data.get(
            "items",
            []
        )

        if len(items):

            login = items[0][
                "login"
            ]

    search_cache[key] = login

    return login


############################################################
# github profile
############################################################

def get_user_profile(
    login
):

    if login in profile_cache:

        return profile_cache[
            login
        ]

    data = github_get(
        f"https://api.github.com/users/{login}"
    )

    profile_cache[
        login
    ] = data

    return data


############################################################
# cache
############################################################

def load_cache():

    if os.path.exists(
        CACHE_FILE
    ):

        with open(
            CACHE_FILE,
            "r",
            encoding="utf-8"
        ) as f:

            return json.load(f)

    return {}


def save_cache(cache):

    with open(
        CACHE_FILE,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            cache,
            f,
            ensure_ascii=False,
            indent=2
        )
        ############################################################
# email -> github profile
############################################################

def github_profile_from_email(
    email,
    author_name,
    cache
):

    cache_key = (
        str(email)
        + "|||"
        + str(author_name)
    )

    if cache_key in cache:

        return cache[
            cache_key
        ]

    login = None

    ########################################################
    # github noreply
    ########################################################

    if (
        email
        and
        email.endswith(
            "@users.noreply.github.com"
        )
    ):

        try:

            left = email.split("@")[0]

            if "+" in left:

                login = (
                    left
                    .split("+",1)[1]
                )

            else:

                login = left

        except:
            pass

    ########################################################
    # email search
    ########################################################

    if login is None:

        login = search_user_by_email(
            email
        )

    ########################################################
    # name search
    ########################################################

    if login is None:

        login = search_user_by_name(
            author_name
        )

    result = {

        "created_at": None,

        "public_repos": -1,

        "login": None
    }

    ########################################################
    # profile
    ########################################################

    if login:

        profile = get_user_profile(
            login
        )

        if profile:

            result = {

                "created_at":
                    profile.get(
                        "created_at"
                    ),

                "public_repos":
                    profile.get(
                        "public_repos",
                        -1
                    ),

                "login":
                    login
            }

    cache[
        cache_key
    ] = result

    return result


############################################################
# git helper
############################################################

def git_lines(
    repo,
    args
):

    try:

        out = subprocess.check_output(
            ["git","-C",repo]
            + args,
            text=True,
            stderr=subprocess.DEVNULL
        )

        return out.splitlines()

    except:

        return []


def get_default_branch(
    repo
):

    for branch in [
        "main",
        "master"
    ]:

        try:

            subprocess.check_output(
                [
                    "git",
                    "-C",
                    repo,
                    "rev-parse",
                    "--verify",
                    branch
                ],
                stderr=subprocess.DEVNULL
            )

            return branch

        except:
            pass

    raise RuntimeError(
        "Cannot find main/master"
    )


############################################################
# commit basic
############################################################

def commit_basic(
    repo,
    sha
):

    fmt = (
        "%H|%an|%ae|%ct"
    )

    row = git_lines(
        repo,
        [
            "show",
            "-s",
            f"--format={fmt}",
            sha
        ]
    )[0]

    (
        sha,
        name,
        email,
        ts
    ) = row.split("|")

    return {

        "sha":
            sha,

        "name":
            name,

        "email":
            email,

        "timestamp":
            int(ts)
    }


############################################################
# commit stat
############################################################

def commit_numstat(
    repo,
    sha
):

    lines = git_lines(
        repo,
        [
            "show",
            "--numstat",
            "--format=",
            sha
        ]
    )

    adds = 0

    deletes = 0

    files = 0

    suffixes = set()

    for line in lines:

        parts = line.split(
            "\t"
        )

        if len(parts) != 3:

            continue

        a,d,path = parts

        if a.isdigit():

            adds += int(a)

        if d.isdigit():

            deletes += int(d)

        files += 1

        ext = Path(
            path
        ).suffix

        if ext:

            suffixes.add(
                ext
            )

    return (
        adds,
        deletes,
        files,
        sorted(
            suffixes
        )
    )


############################################################
# PR commits
############################################################

def find_pr_commits(
    repo,
    branch
):

    all_commits = set(

        git_lines(
            repo,
            [
                "rev-list",
                branch
            ]
        )

    )

    merge_lines = git_lines(

        repo,

        [
            "log",
            branch,
            "--merges",
            "--pretty=format:%H %P"
        ]
    )

    pr_commits = set()

    merge_commits = set()

    for line in merge_lines:

        parts = (
            line
            .strip()
            .split()
        )

        if len(parts) < 3:

            continue

        merge_sha = parts[0]

        parent1 = parts[1]

        parent2 = parts[2]

        merge_commits.add(
            merge_sha
        )

        commits = git_lines(

            repo,

            [
                "rev-list",
                parent2,
                f"^{parent1}"
            ]
        )

        pr_commits.update(
            commits
        )

    direct_commits = (

        all_commits
        - pr_commits
        - merge_commits
    )

    return (
        pr_commits,
        direct_commits
    )
############################################################
# user activity
############################################################

def max_commits_24h(
    times
):

    if not times:

        return 0

    times = sorted(
        times
    )

    i = 0

    best = 1

    for j in range(
        len(times)
    ):

        while (
            times[j]
            - times[i]
            > 86400
        ):

            i += 1

        best = max(
            best,
            j - i + 1
        )

    return best


############################################################
# main
############################################################

def process_repo(repo_path):

    repo_name = os.path.basename(
        os.path.abspath(repo_path)
    )

    os.makedirs(
        OUTPUT_DIR,
        exist_ok=True
    )

    OUTPUT_JSONL = os.path.join(
        OUTPUT_DIR,
        f"{repo_name}.jsonl"
    )

    cache = load_cache()

    branch = get_default_branch(
        repo_path
    )

    print(
        "default branch:",
        branch
    )

    ########################################################
    # pr/direct
    ########################################################

    print(
        "finding pr commits..."
    )

    (
        pr_commits,
        direct_commits
    ) = find_pr_commits(
        repo_path,
        branch
    )

    print(
        "pr commits:",
        len(pr_commits)
    )

    print(
        "direct commits:",
        len(direct_commits)
    )

    ########################################################
    # commit list
    ########################################################

    commit_list = git_lines(
        repo_path,
        [
            "rev-list",
            "--reverse",
            branch
        ]
    )

    print(
        "total commits:",
        len(commit_list)
    )

    ########################################################
    # user data
    ########################################################

    user_commits = defaultdict(
        list
    )

    user_emails = defaultdict(
        set
    )

    ########################################################
    # scan commit
    ########################################################

    print(
        "Phase1 scanning commits..."
    )

    for sha in tqdm(
        commit_list
    ):

        try:

            info = commit_basic(
                repo_path,
                sha
            )

            (
                adds,
                deletes,
                files,
                types
            ) = commit_numstat(
                repo_path,
                sha
            )

            info.update({

                "adds":
                    adds,

                "deletes":
                    deletes,

                "files":
                    files,

                "types":
                    types
            })

            email = info[
                "email"
            ]

            user_commits[
                email
            ].append(
                info
            )

            user_emails[
                email
            ].add(
                email
            )

        except Exception as e:

            print(
                "scan commit error:",
                sha,
                e
            )

    ########################################################
    # github profile
    ########################################################

    print(
        "Phase2 github profile..."
    )

    user_profile = {}

    for (
        email,
        commits
    ) in tqdm(
        user_commits.items()
    ):

        try:

            author_name = commits[
                0
            ][
                "name"
            ]

            profile = (
                github_profile_from_email(
                    email,
                    author_name,
                    cache
                )
            )

            ################################################
            # age
            ################################################

            first_commit_ts = min(

                c["timestamp"]

                for c in commits

            )

            age_days = -1

            if profile[
                "created_at"
            ]:

                try:

                    created = (
                        datetime
                        .fromisoformat(
                            profile[
                                "created_at"
                            ]
                            .replace(
                                "Z",
                                "+00:00"
                            )
                        )
                    )

                    age_days = (

                        datetime
                        .fromtimestamp(
                            first_commit_ts,
                            tz=timezone.utc
                        )

                        -

                        created

                    ).days

                    age_days = max(
                        age_days,
                        0
                    )

                except:

                    pass

            ################################################
            # pr count
            ################################################

            pr_count = sum(

                1

                for c in commits

                if c["sha"]
                in pr_commits

            )

            ################################################
            # direct count
            ################################################

            direct_count = sum(

                1

                for c in commits

                if c["sha"]
                in direct_commits

            )

            ################################################
            # max commits 24h
            ################################################

            max24 = (
                max_commits_24h(
                    [
                        c["timestamp"]
                        for c in commits
                    ]
                )
            )

            ################################################
            # volunteer
            ################################################

            domains = [

                e
                .split("@")[-1]
                .lower()

                for e in user_emails[
                    email
                ]

            ]

            volunteer = all(

                d
                in PUBLIC_EMAIL_DOMAINS

                for d in domains
            )

            ################################################
            # user profile
            ################################################

            user_profile[
                email
            ] = {

                "experience": {

                    "age":
                        age_days,

                    "repos":
                        profile[
                            "public_repos"
                        ]
                },

                "active": {

                    "prs":
                        pr_count,

                    "non_prs":
                        direct_count,

                    "multi_commits":
                        max24
                },

                "identity": {

                    "multi_accounts":
                        -1,

                    "volunteer":
                        volunteer
                }
            }

        except Exception as e:

            print(
                "profile error:",
                email,
                e
            )

    save_cache(
        cache
    )
        ########################################################
    # output jsonl
    ########################################################

    print(
        "Phase3 writing jsonl..."
    )

    with open(
        OUTPUT_JSONL,
        "w",
        encoding="utf-8"
    ) as fout:

        for (
            email,
            commits
        ) in tqdm(
            user_commits.items()
        ):

            commits = sorted(

                commits,

                key=lambda x:
                x["timestamp"]

            )

            ################################################
            # history accumulator
            ################################################

            sum_adds = 0

            sum_deletes = 0

            sum_files = 0

            intervals = []

            ################################################
            # commit loop
            ################################################

            for idx,c in enumerate(
                commits
            ):
                left = 0
                while (
                    c["timestamp"]
                    - commits[left]["timestamp"]
                    > 86400
                ):
                    left += 1

                multi_commits = idx - left + 1

                ############################################
                # distance
                ############################################

                if idx > 0:

                    intervals.append(

                        (
                            c["timestamp"]
                            -
                            commits[
                                idx-1
                            ][
                                "timestamp"
                            ]
                        )
                        /
                        3600.0

                    )

                distance = (

                    median(
                        intervals
                    )

                    if intervals

                    else 0

                )

                ############################################
                # history avg
                ############################################

                prev_count = idx

                avg_adds = (

                    sum_adds
                    /
                    prev_count

                    if prev_count

                    else 0
                )

                avg_deletes = (

                    sum_deletes
                    /
                    prev_count

                    if prev_count

                    else 0
                )

                avg_files = (

                    sum_files
                    /
                    prev_count

                    if prev_count

                    else 0
                )

                user_info = json.loads(
                    json.dumps(
                        user_profile[email]
                    )
                )

                user_info["active"]["multi_commits"] = (
                    multi_commits
                )

                ############################################
                # record
                ############################################

                record = {

                    "sha":
                        c["sha"],

                    "author_name":
                        c["name"],

                    "author_email":
                        c["email"],

                    "user":user_info,

                    "commit": {

                        ####################################
                        # habit
                        ####################################

                        "habit": {

                            "commit_time":

                                datetime
                                .utcfromtimestamp(
                                    c[
                                        "timestamp"
                                    ]
                                )
                                .isoformat()

                                + "Z",

                            "commit_type":
                                "default",

                            "distance":
                                distance
                        },

                        ####################################
                        # scale
                        ####################################

                        "scale": {

                            "adds":
                                c["adds"],

                            "deletes":
                                c["deletes"],

                            "files":
                                c["files"],

                            "types":
                                c["types"]
                        },

                        ####################################
                        # history
                        ####################################

                        "history": {

                            "avg_adds":
                                avg_adds,

                            "avg_deletes":
                                avg_deletes,

                            "avg_files":
                                avg_files,

                            "prev_commit_count":
                                prev_count
                        },

                        ####################################
                        # delta
                        ####################################

                        "delta": {

                            "delta_adds":

                                abs(
                                    c["adds"]
                                    -
                                    avg_adds
                                ),

                            "delta_deletes":

                                abs(
                                    c["deletes"]
                                    -
                                    avg_deletes
                                ),

                            "delta_files":

                                abs(
                                    c["files"]
                                    -
                                    avg_files
                                )
                        }
                    }
                }

                ############################################
                # write
                ############################################

                fout.write(

                    json.dumps(
                        record,
                        ensure_ascii=False
                    )

                    + "\n"

                )

                ############################################
                # update history
                ############################################

                sum_adds += c[
                    "adds"
                ]

                sum_deletes += c[
                    "deletes"
                ]

                sum_files += c[
                    "files"
                ]

    ########################################################
    # save cache
    ########################################################

    save_cache(
        cache
    )

    print()

    print(
        "Done:"
    )

    print(
        OUTPUT_JSONL
    )


############################################################
# entry
############################################################

############################################################
# entry
############################################################

def main():

    repos = []

    for name in sorted(os.listdir(REPOS_ROOT)):

        repo_path = os.path.join(
            REPOS_ROOT,
            name
        )

        if not os.path.isdir(repo_path):
            continue

        try:

            subprocess.check_output(
                [
                    "git",
                    "-C",
                    repo_path,
                    "rev-parse",
                    "--git-dir"
                ],
                stderr=subprocess.DEVNULL,
                text=True
            )

            repos.append(repo_path)

        except:
            pass

    print(
        f"Found {len(repos)} repos"
    )

    for repo_path in repos:

        print()
        print("=" * 80)
        print(
            "Processing:",
            repo_path
        )
        print("=" * 80)

        try:

            process_repo(
                repo_path
            )

        except Exception as e:

            print(
                "FAILED:",
                repo_path,
                e
            )

    print()
    print("ALL DONE")


if __name__ == "__main__":
    main()