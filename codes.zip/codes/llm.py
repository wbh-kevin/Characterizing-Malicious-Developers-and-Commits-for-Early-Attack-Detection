#!/usr/bin/env python3
# -*- coding:utf-8 -*-

import os
import json
import time
import requests
import pandas as pd

from string import Template

############################################################
# CONFIG
############################################################

INPUT_DIR = "jsonl33"

OUTPUT_DIR = "llm_out"

FAILED_DIR = "failed"

API_KEY = ""

API_URL = ""

MODEL = ""

SLEEP = 1

os.makedirs(
    OUTPUT_DIR,
    exist_ok=True
)

os.makedirs(
    FAILED_DIR,
    exist_ok=True
)

############################################################
# PROMPT
############################################################

PROMPT_TEMPLATE = Template(r"""
You are analyzing whether a commit resembles the behavior observed in historical malicious open-source software supply-chain incidents.

====================================================
Commit Features
===============

Developer Profile

* Repository experience: $repos

Developer Activity History

* PR activities: $prs
* Non-PR activities: $non_prs
* Multi-commit activities: $multi_commits
* Multi-account identities: $multi_accounts
* Previous commit count: $prev_commit_count

Current Commit

* Lines added: $cur_additions
* Lines deleted: $cur_deletions
* Files modified: $cur_files
* File types: $file_type

Historical Baseline

* Historical average additions: $avg_adds
* Historical average deletions: $avg_deletes
* Historical average modified files: $avg_files

Developer History Scale

* Previous files modified: $prev_file_count
* Previous additions: $prev_additions
* Previous deletions: $prev_deletions

Commit Timing

* Hour deviation: $hour_deviation

====================================================
Empirical Benign Population Profile
===================================

Typical benign contributors commonly exhibit:

* Larger historical contribution footprints.
* More sustained development activity over time.
* Larger historical average additions.
* Larger historical average deletions.
* Larger historical average modified-file counts.
* Frequent PR participation.
* Consistent contribution patterns across many commits.
* Commit sizes generally align with historical behavior.

====================================================
Empirical Malicious-like Population Profile
===========================================

Historically observed malicious-like commits more frequently exhibit:

* Smaller historical contribution footprints.
* Few or no PR activities.
* Small historical average additions.
* Small historical average deletions.
* Small historical average modified-file counts.
* Abrupt deviations from historical behavior.
* Current commits that modify substantially more code than the contributor's historical baseline.
* Current commits that touch substantially more files than the contributor's historical baseline.
* Large modification scope concentrated in a single commit.

====================================================
Feature Importance Guidance
===========================

Very Strong Indicators

* avg_files
* prs
* avg_deletes
* cur_additions

Strong Indicators

* avg_adds
* cur_files

Moderate Indicators

* prev_commit_count
* non_prs

Weak Indicators

* cur_deletions

Very Weak Indicators

* multi_commits
* hour_deviation

When conflicts occur between features,
stronger indicators should generally
receive more weight than weaker indicators.

Pay particular attention to behavioral deviation.

A contributor with a long history can still be risky
if the current commit is dramatically different from
their historical baseline.

A contributor with little history is not automatically malicious.

Do not rely on any single feature.

Evaluate the overall behavioral profile.

====================================================
Behavioral Reasoning Guidance
=============================

The most important signal is whether the current commit
appears unusually large relative to the contributor's
historical behavior.

Examples of suspicious patterns include:

* Very small historical average additions but extremely large current additions.
* Very small historical average modified-file counts but many files modified in the current commit.
* Minimal historical activity followed by a large-scale change.
* Few PR activities combined with unusually large modifications.

Examples of benign patterns include:

* Current commit size is consistent with historical behavior.
* Historical activity level and current activity level are aligned.
* Large commits performed by contributors with a long history of similarly large commits.

====================================================
Task
====

Real malicious commits are extremely rare.

Make your decision carefully.

Determine whether this commit is more similar to:

A) malicious-like population

or

B) benign-like population

Return ONLY valid JSON.

{
"risk_score": integer,
"classification": "malicious-like|benign-like",
"confidence": integer,
"key_features": [
"feature1",
"feature2"
],
"reason": "short explanation"
}
""")


############################################################
# API
############################################################

def ask_llm(prompt):

    payload = {
        "model": MODEL,
        "messages": [
            {
                "role": "user",
                "content": prompt
            }
        ],
        "temperature": 0.2
    }

    headers = {
        "Authorization":
            f"Bearer {API_KEY}",
        "Content-Type":
            "application/json"
    }

    r = requests.post(
        API_URL,
        headers=headers,
        json=payload,
        timeout=300
    )

    if r.status_code != 200:

        raise RuntimeError(
            f"HTTP {r.status_code}: "
            + r.text[:1000]
        )

    data = r.json()

    try:

        return (
            data["choices"][0]
            ["message"]["content"]
        )

    except Exception:

        raise RuntimeError(
            "No content returned"
        )

############################################################
# JSON parser
############################################################

def parse_response(text):

    try:

        start = text.find("{")

        end = text.rfind("}")

        if start != -1 and end != -1:

            text = text[
                start:end+1
            ]

        obj = json.loads(text)

        return (

            obj.get(
                "risk_score"
            ),

            obj.get(
                "classification"
            ),

            obj.get(
                "confidence"
            ),

            ",".join(
                obj.get(
                    "key_features",
                    []
                )
            ),

            obj.get(
                "reason",
                ""
            )
        )

    except Exception:

        return (
            None,
            None,
            None,
            None,
            None
        )
    ############################################################
# FAILED RECORD
############################################################

def save_failed(
    failed_file,
    obj,
    error_type,
    error_msg
):

    record = {

        "sha":
            obj.get(
                "sha"
            ),

        "author_name":
            obj.get(
                "author_name"
            ),

        "author_email":
            obj.get(
                "author_email"
            ),

        "group":
            obj.get(
                "group"
            ),

        "error_type":
            error_type,

        "error":
            str(error_msg)
    }

    with open(
        failed_file,
        "a",
        encoding="utf-8"
    ) as f:

        f.write(
            json.dumps(
                record,
                ensure_ascii=False
            )
            + "\n"
        )

############################################################
# RESUME SUPPORT
############################################################

def load_done_shas(
    csv_file
):

    if not os.path.exists(
        csv_file
    ):

        return set()

    try:

        df = pd.read_csv(
            csv_file
        )

        if "sha" not in df.columns:

            return set()

        return set(

            df["sha"]
            .astype(str)
            .tolist()

        )

    except Exception:

        return set()

############################################################
# CSV APPEND
############################################################

def append_csv(
    csv_file,
    row
):

    df = pd.DataFrame(
        [row]
    )

    if os.path.exists(
        csv_file
    ):

        df.to_csv(
            csv_file,
            mode="a",
            header=False,
            index=False
        )

    else:

        df.to_csv(
            csv_file,
            index=False
        )

############################################################
# SINGLE REPO
############################################################

def process_repo_file(
    input_jsonl
):

    repo_name = (

        os.path.basename(
            input_jsonl
        )

        .replace(
            ".jsonl",
            ""
        )

    )

    csv_file = os.path.join(

        OUTPUT_DIR,

        repo_name
        + ".csv"
    )

    failed_file = os.path.join(

        FAILED_DIR,

        repo_name
        + "_failed.jsonl"
    )

    print()
    print("=" * 80)
    print("Repository:", repo_name)

    ########################################################
    # already done
    ########################################################

    done_shas = load_done_shas(
        csv_file
    )

    print(
        "already done:",
        len(done_shas)
    )

    ########################################################
    # load records
    ########################################################

    records = []

    with open(
        input_jsonl,
        "r",
        encoding="utf-8"
    ) as f:

        for line in f:

            line = line.strip()

            if not line:
                continue

            try:

                obj = json.loads(
                    line
                )

            except Exception:

                continue

            sha = str(
                obj.get(
                    "sha",
                    ""
                )
            )

            if sha in done_shas:

                continue

            records.append(
                obj
            )

    print(
        "remaining:",
        len(records)
    )

    ########################################################
    # commit loop
    ########################################################

    for idx, obj in enumerate(
        records
    ):

        print(
            f"[{idx+1}/{len(records)}]"
        )

        sha = obj["sha"]

        user = obj["user"]

        commit = obj["commit"]

        prev_commit_count = (

            commit["history"][
                "prev_commit_count"
            ]

        )

        avg_adds = (

            commit["history"][
                "avg_adds"
            ]

        )

        avg_deletes = (

            commit["history"][
                "avg_deletes"
            ]

        )

        avg_files = (

            commit["history"][
                "avg_files"
            ]

        )

        prev_additions = avg_adds

        prev_deletions = avg_deletes

        prev_file_count = avg_files
                ####################################################
        # build prompt
        ####################################################

        try:

            prompt = PROMPT_TEMPLATE.substitute(

                repos=
                    user["experience"][
                        "repos"
                    ],

                prs=
                    user["active"][
                        "prs"
                    ],

                non_prs=
                    user["active"][
                        "non_prs"
                    ],

                multi_commits=
                    user["active"][
                        "multi_commits"
                    ],

                multi_accounts=
                    user["identity"][
                        "multi_accounts"
                    ],

                prev_commit_count=
                    prev_commit_count,

                cur_additions=
                    commit["scale"][
                        "adds"
                    ],

                cur_deletions=
                    commit["scale"][
                        "deletes"
                    ],

                cur_files=
                    commit["scale"][
                        "files"
                    ],

                file_type=
                    ",".join(
                        commit["scale"][
                            "types"
                        ]
                    ),

                avg_adds=
                    avg_adds,

                avg_deletes=
                    avg_deletes,

                avg_files=
                    avg_files,

                prev_file_count=
                    round(
                        prev_file_count,
                        2
                    ),

                prev_additions=
                    round(
                        prev_additions,
                        2
                    ),

                prev_deletions=
                    round(
                        prev_deletions,
                        2
                    ),

                hour_deviation=0
            )

        except Exception as e:

            save_failed(
                failed_file,
                obj,
                "prompt_error",
                e
            )

            continue

        ####################################################
        # call llm
        ####################################################

        try:

            answer = ask_llm(
                prompt
            )

        except requests.exceptions.RequestException as e:

            save_failed(
                failed_file,
                obj,
                "network_error",
                e
            )

            continue

        except Exception as e:

            save_failed(
                failed_file,
                obj,
                "api_error",
                e
            )

            continue

        ####################################################
        # empty response
        ####################################################

        if (
            answer is None
            or
            not str(answer).strip()
        ):

            save_failed(
                failed_file,
                obj,
                "empty_response",
                "no content"
            )

            continue

        ####################################################
        # quota / balance
        ####################################################

        answer_lower = (
            answer.lower()
        )

        if any(

            keyword
            in
            answer_lower

            for keyword in [

                "quota",

                "insufficient",

                "balance",

                "credit",

                "rate limit",

                "exceeded",

                "billing"
            ]
        ):

            save_failed(
                failed_file,
                obj,
                "quota_error",
                answer[:1000]
            )

            continue

        ####################################################
        # parse response
        ####################################################

        (
            risk,
            cls,
            conf,
            features,
            reason
        ) = parse_response(
            answer
        )

        ####################################################
        # save row
        ####################################################

        row = {

            "sha":
                sha,

            "author_name":
                obj[
                    "author_name"
                ],

            "author_email":
                obj[
                    "author_email"
                ],

            "group":
                obj.get(
                    "group"
                ),

            "risk_score":
                risk,

            "classification":
                cls,

            "confidence":
                conf,

            "key_features":
                features,

            "reason":
                reason,

            "raw_response":
                answer
        }

        append_csv(
            csv_file,
            row
        )

        time.sleep(
            SLEEP
        )

    print(
        "finished:",
        repo_name
    )

############################################################
# MAIN
############################################################

def main():

    files = sorted(

        os.path.join(
            INPUT_DIR,
            f
        )

        for f in os.listdir(
            INPUT_DIR
        )

        if f.endswith(
            ".jsonl"
        )
    )

    print(
        "repositories:",
        len(files)
    )

    for file_path in files:

        try:

            process_repo_file(
                file_path
            )

        except Exception as e:

            print()

            print(
                "FAILED REPOSITORY:"
            )

            print(
                file_path
            )

            print(
                e
            )

    print()
    print("=" * 80)
    print("ALL DONE")
    print("=" * 80)

############################################################
# ENTRY
############################################################

if __name__ == "__main__":

    main()